package com.StayFinder.StayFinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StayFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
